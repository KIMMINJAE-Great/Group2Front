import { Component } from "react";

class Test extends Component {

  


  render() {
  
  

    return (
      <div>
        <h1>들어오면 안되요</h1>
      </div>
    )
  }
}

export default Test;